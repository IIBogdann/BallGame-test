package com.DefaultCompany.AndroidGame;

public final class R {

    public static final class id {
        public static final int unitySurfaceView = 2130771968;

        private id() {
        }
    }

    public static final class mipmap {
        public static final int app_icon = 2130837504;
        public static final int app_icon_round = 2130837505;
        public static final int ic_launcher_background = 2130837506;
        public static final int ic_launcher_foreground = 2130837507;

        private mipmap() {
        }
    }

    public static final class string {
        public static final int app_name = 2130903040;
        public static final int game_view_content_description = 2130903041;

        private string() {
        }
    }

    public static final class style {
        public static final int BaseUnityTheme = 2130968576;
        public static final int UnityThemeSelector = 2130968577;
        public static final int UnityThemeSelector_Translucent = 2130968578;

        private style() {
        }
    }

    private R() {
    }
}
