package com.unity3d.player;

import android.app.Activity;
import android.content.Context;
import com.unity3d.player.m;
import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

final class n {
    /* access modifiers changed from: private */
    public UnityPlayer a = null;
    /* access modifiers changed from: private */
    public Context b = null;
    private a c;
    /* access modifiers changed from: private */
    public final Semaphore d = new Semaphore(0);
    /* access modifiers changed from: private */
    public final Lock e = new ReentrantLock();
    /* access modifiers changed from: private */
    public m f = null;
    /* access modifiers changed from: private */
    public int g = 2;
    private boolean h = false;
    /* access modifiers changed from: private */
    public boolean i = false;

    public interface a {
        void a();
    }

    n(UnityPlayer unityPlayer) {
        this.a = unityPlayer;
    }

    /* access modifiers changed from: private */
    public void d() {
        m mVar = this.f;
        if (mVar != null) {
            this.a.removeViewFromPlayer(mVar);
            this.i = false;
            this.f.destroyPlayer();
            this.f = null;
            a aVar = this.c;
            if (aVar != null) {
                aVar.a();
            }
        }
    }

    public final void a() {
        this.e.lock();
        m mVar = this.f;
        if (mVar != null) {
            if (this.g == 0) {
                mVar.CancelOnPrepare();
            } else if (this.i) {
                boolean a2 = mVar.a();
                this.h = a2;
                if (!a2) {
                    this.f.pause();
                }
            }
        }
        this.e.unlock();
    }

    public final boolean a(Context context, String str, int i2, int i3, int i4, boolean z, long j, long j2, a aVar) {
        this.e.lock();
        this.c = aVar;
        this.b = context;
        this.d.drainPermits();
        this.g = 2;
        final String str2 = str;
        final int i5 = i2;
        final int i6 = i3;
        final int i7 = i4;
        final boolean z2 = z;
        final long j3 = j;
        final long j4 = j2;
        runOnUiThread(new Runnable() {
            public final void run() {
                if (n.this.f != null) {
                    f.Log(5, "Video already playing");
                    int unused = n.this.g = 2;
                    n.this.d.release();
                    return;
                }
                m unused2 = n.this.f = new m(n.this.b, str2, i5, i6, i7, z2, j3, j4, new m.a() {
                    public final void a(int i) {
                        n.this.e.lock();
                        int unused = n.this.g = i;
                        if (i == 3 && n.this.i) {
                            n.this.runOnUiThread(new Runnable() {
                                public final void run() {
                                    n.this.d();
                                    n.this.a.resume();
                                }
                            });
                        }
                        if (i != 0) {
                            n.this.d.release();
                        }
                        n.this.e.unlock();
                    }
                });
                if (n.this.f != null) {
                    n.this.a.addView(n.this.f);
                }
            }
        });
        boolean z3 = false;
        try {
            this.e.unlock();
            this.d.acquire();
            this.e.lock();
            if (this.g != 2) {
                z3 = true;
            }
        } catch (InterruptedException unused) {
        }
        runOnUiThread(new Runnable() {
            public final void run() {
                n.this.a.pause();
            }
        });
        runOnUiThread((!z3 || this.g == 3) ? new Runnable() {
            public final void run() {
                n.this.d();
                n.this.a.resume();
            }
        } : new Runnable() {
            public final void run() {
                if (n.this.f != null) {
                    n.this.a.addViewToPlayer(n.this.f, true);
                    boolean unused = n.this.i = true;
                    n.this.f.requestFocus();
                }
            }
        });
        this.e.unlock();
        return z3;
    }

    public final void b() {
        this.e.lock();
        m mVar = this.f;
        if (mVar != null && this.i && !this.h) {
            mVar.start();
        }
        this.e.unlock();
    }

    public final void c() {
        this.e.lock();
        m mVar = this.f;
        if (mVar != null) {
            mVar.updateVideoLayout();
        }
        this.e.unlock();
    }

    /* access modifiers changed from: protected */
    public final void runOnUiThread(Runnable runnable) {
        Context context = this.b;
        if (context instanceof Activity) {
            ((Activity) context).runOnUiThread(runnable);
        } else {
            f.Log(5, "Not running from an Activity; Ignoring execution request...");
        }
    }
}
