package com.unity3d.player;

public interface e {
    void a(Object obj);

    void a(Object obj, Object obj2, Object obj3, int i, int i2, int i3);
}
