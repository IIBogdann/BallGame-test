package com.unity3d.player;

interface IAssetPackManagerDownloadStatusCallback {
    void onStatusUpdate(String str, int i, long j, long j2, int i2, int i3);
}
