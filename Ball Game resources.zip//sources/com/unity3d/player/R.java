package com.unity3d.player;

public final class R {

    public static final class style {
        public static final int BaseUnityTheme = 2130968576;
        public static final int UnityThemeSelector = 2130968577;
        public static final int UnityThemeSelector_Translucent = 2130968578;

        private style() {
        }
    }

    private R() {
    }
}
