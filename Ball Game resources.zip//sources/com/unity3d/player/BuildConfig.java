package com.unity3d.player;

public final class BuildConfig {
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String LIBRARY_PACKAGE_NAME = "com.unity3d.player";
    public static final int VERSION_CODE = 1;
    public static final String VERSION_NAME = "1.0";
}
