package com.unity3d.player;

public interface IUnityPlayerLifecycleEvents {
    void onUnityPlayerQuitted();

    void onUnityPlayerUnloaded();
}
