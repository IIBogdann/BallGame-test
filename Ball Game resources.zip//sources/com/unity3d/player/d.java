package com.unity3d.player;

import android.app.Activity;

interface d {
    Object a(IAssetPackManagerDownloadStatusCallback iAssetPackManagerDownloadStatusCallback);

    String a(String str);

    void a(Activity activity, IAssetPackManagerMobileDataConfirmationCallback iAssetPackManagerMobileDataConfirmationCallback);

    void a(Object obj);

    void a(String[] strArr);

    void a(String[] strArr, IAssetPackManagerDownloadStatusCallback iAssetPackManagerDownloadStatusCallback);

    void a(String[] strArr, IAssetPackManagerStatusQueryCallback iAssetPackManagerStatusQueryCallback);

    void b(String str);
}
